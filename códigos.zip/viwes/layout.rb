<!DOCTYPE html>
<html>
  <head>
    <meta charset='UTF-8' />
    <title>Sufragista</title>
    <link href='//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.1/css/bootstrap-combined.min.css' rel='stylesheet' />
  </head>
  <body class='container'>
    <h1><%= @titulo %></h1>
    <%= yield %>
  </body>
</html>