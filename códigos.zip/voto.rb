require 'sinatra'

get '/' do
  'Olá, eleitor!'
end